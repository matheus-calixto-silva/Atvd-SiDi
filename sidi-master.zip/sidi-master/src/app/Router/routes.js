export const routes = {
  home: '/',
  login: '/login',
  start: '/inicio',
  register: '/cadastro',
  forgotPassword: '/esqueci-senha',
  notFound: '*',
};
