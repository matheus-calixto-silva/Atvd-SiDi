import Router from './app/Router';

const App = () => <Router />;

export default App;
